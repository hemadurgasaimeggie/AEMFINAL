import React from 'react';
import Slider from '@mui/material/Slider';
import Typography from '@mui/material/Typography';

const CustomSlider = ({ label, value, onChange, min, max, step }) => {
  const handleChange = (event, newValue) => {
    onChange(newValue);
  };

  return (
    <div>
      <Typography id="discrete-slider" gutterBottom>
        {label}
      </Typography>
      <Slider
        value={value}
        onChange={handleChange}
        aria-labelledby="discrete-slider"
        valueLabelDisplay="auto"
        step={step}
        marks
        min={min}
        max={max}
      />
    </div>
  );
};

export default CustomSlider;