import React, { useState } from "react";
import {
  TextField,
  Button,
  Select,
  MenuItem,
  Typography,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Tabs,
  Tab,
  Tooltip,
  Checkbox,
  InputAdornment,
  Slider,
} from "@mui/material";
import jsonData from "../form-model.json";

const FormRenderer = () => {
  const json = jsonData?.[":items"]?.tabsontop;
  const jsons = jsonData?.[":items"]?.panelcontainer;
  const [formData, setFormData] = useState({});
  const [errors, setErrors] = useState({});
  const [activeTab, setActiveTab] = useState(0);
  const handleChange = (name, value) => {
    setFormData({ ...formData, [name]: value });
    // Add your validation logic here
  };
  const [checkboxState, setCheckboxState] = useState({});

  const handleCheckboxChange = (name) => (event) => {
    setCheckboxState({
      ...checkboxState,
      [name]: event.target.checked,
    });
  };
  const handleButtonClick = () => {
    console.log("Errors object:", errors);

    // Check if errors is defined and an object
    if (errors && typeof errors === "object") {
      // Check if there are any errors
      const hasErrors = Object.values(errors).some(
        (error) => error && Object.keys(error).length > 0
      );
      console.log("Has errors:", hasErrors);
      // If there are no errors, submit the form
      if (!hasErrors) {
        console.log(formData);
      } else {
        console.log("Form has errors");
      }
    } else {
      console.log("No errors found");
    }
  };
  const renderField = (item) => {
    const errorMessage = errors[item?.name];
    const hasValidationError =
      errorMessage && errorMessage.validationExpression;
    const hasPatternError = errorMessage && errorMessage.pattern;

    switch (item?.fieldType) {
      case "text-input":
        return (
          <Tooltip title={item?.description} arrow>
            <TextField
              sx={{ mb: 2 }}
              key={item.name}
              label={item.label.value}
              required={item.required}
              fullWidth
              value={formData[item.name] || ""}
              onChange={(e) => handleChange(item.name, e.target.value)}
              error={hasValidationError || hasPatternError} // Apply error state if validation error exists
              helperText={
                hasPatternError ? errorMessage.pattern : errorMessage?.required
              } // Display required or pattern error message
              inputProps={{
                pattern: item.pattern || undefined,
              }}
              InputProps={{
                endAdornment: hasValidationError && (
                  <InputAdornment position="end">
                    {errorMessage.validationExpression}
                  </InputAdornment>
                ),
              }}
            />
          </Tooltip>
        );
      case "number-input":
        return (
          <Tooltip title={item?.description} arrow>
            <TextField
              sx={{ mb: 2 }}
              type="number"
              key={item?.name}
              label={item?.label?.value}
              fullWidth
              style={{ display: "flex" }}
              required={item?.required}
              defaultValue={item?.default}
              value={formData[item?.name]}
              onChange={(e) => handleChange(item?.name, e.target.value)}
              error={!!errorMessage} // Apply error state if validation error exists
              helperText={errorMessage} // Display validation error message
            />
          </Tooltip>
        );
      case "checkbox-group":
        if (item?.enum && item?.enumNames) {
          return (
            <div key={item?.name}>
              {item?.enum.map((option, index) => (
                <div
                  key={option}
                  style={{ display: "flex", alignItems: "center" }}
                >
                  {/* Update the checked prop based on formData */}
                  <Checkbox
                    checked={formData[item?.name]?.includes(option) || false}
                    onChange={(e) => {
                      // Update the formData state when checkbox is clicked
                      const isChecked = e.target.checked;
                      const updatedFormData = {
                        ...formData,
                        [item?.name]: isChecked
                          ? [...(formData[item?.name] || []), option]
                          : (formData[item?.name] || []).filter(
                              (selectedOption) => selectedOption !== option
                            ),
                      };
                      handleChange(item?.name, updatedFormData[item?.name]);
                    }}
                  />
                  <Typography>{item?.enumNames[index]}</Typography>
                </div>
              ))}
            </div>
          );
        }
        return null; // Handle case where options are not provided
      case "drop-down":
        return (
          <Tooltip title={item?.description} arrow>
            <Select
              sx={{ mb: 2 }}
              key={item?.name}
              value={formData[item?.name] || ""}
              onChange={(e) => handleChange(item?.name, e.target.value)}
              fullWidth
              style={{ display: "flex" }}
              displayEmpty // Allow the placeholder to be displayed
              renderValue={(selected) =>
                selected ? selected : item?.label?.value
              } // Render the placeholder text when no option is selected
            >
              {item?.enum.map((option) => (
                <MenuItem key={option} value={option}>
                  {option}
                </MenuItem>
              ))}
            </Select>
          </Tooltip>
        );
      case "button":
        return (
          <Button
            sx={{ mb: 2 ,ml:2}}
            key={item?.name}
            variant="contained"
            onClick={() => handleButtonClick(item)} // Pass the item to handleButtonClick
          >
            {item?.label?.value}
          </Button>
        );
      case "plain-text":
        return (
          <Typography
            variant="body1"
            key={item.name}
            sx={{ mb: 2 }}
            dangerouslySetInnerHTML={{ __html: item.value }}
          />
        );
      case "panel":
        return (
          <Accordion key={item.id} sx={{mb:2}}>
            <AccordionSummary>{item.label.value}</AccordionSummary>
            <AccordionDetails>
              <div>
                {item[":itemsOrder"] &&
                  item[":itemsOrder"].map((panelKey) => {
                    const panel = item[":items"][panelKey];
                    return (
                      <div key={panel.id}>
                        {panel[":itemsOrder"] &&
                          panel[":itemsOrder"].map((fieldKey) => {
                            const field = panel[":items"][fieldKey];
                            return renderField(field);
                          })}
                      </div>
                    );
                  })}
              </div>
            </AccordionDetails>
          </Accordion>
        );
      case "custom:slider":
        return (
          <div style={{ display: "flex", alignItems: "center" }}>
            <Tooltip title={item?.description} arrow>
              <Typography
                id={`${item?.name}-label`}
                sx={{ marginRight: "830px" }}
              >
                {item?.label?.value}
              </Typography>
              <Slider
                sx={{ mb: 2 }}
                value={formData[item?.name] || item?.default}
                min={item?.minimum || 0}
                max={item?.maximum || 100}
                step={item?.step || 1}
                defaultValue={item?.default}
                onChange={(event, newValue) =>
                  handleChange(item?.name, newValue)
                }
                aria-labelledby={`${item?.name}-label`}
                onMouseEnter={() => {
                  const newValue = formData[item?.name] || item?.default || 0;
                  if (newValue < (item?.minimum || 0)) {
                    setErrors({
                      ...errors,
                      [item?.name]: item?.constraintMessages?.minimum,
                    });
                  } else if (newValue > (item?.maximum || 100)) {
                    setErrors({
                      ...errors,
                      [item?.name]: item?.constraintMessages?.maximum,
                    });
                  } else {
                    setErrors({
                      ...errors,
                      [item?.name]: undefined,
                    });
                  }
                }}
              />
            </Tooltip>
            <Typography>
              {formData[item?.name] || item?.default || 0}
            </Typography>{" "}
            {/* Display the value here */}
            {/* Display the value here */}
            {formData[item?.name] < (item?.minimum || 0) && (
              <Typography color="error">
                {item?.constraintMessages?.minimum}
              </Typography>
            )}
            {formData[item?.name] > (item?.maximum || 100) && (
              <Typography color="error">
                {item?.constraintMessages?.maximum}
              </Typography>
            )}
          </div>
        );
      default:
        return null;
    }
  };

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  return (
    <div>
      <Tabs value={activeTab} onChange={handleTabChange}>
        {json &&
          json[":itemsOrder"].map((tabKey, tabIndex) => {
            const tab = json[":items"][tabKey];
            return (
              <Tab
                key={tab.id}
                label={tab.label?.value || ""}
                onClick={() => setActiveTab(tabIndex)}
              />
            );
          })}
      </Tabs>
      {json &&
  json[":itemsOrder"] &&
  json[":itemsOrder"].map((tabKey, tabIndex) => {
    const tab = json[":items"][tabKey];
    return (
      <div key={tab.id} hidden={activeTab !== tabIndex}>
        {tab[":itemsOrder"] && (
          <div>
            {tab[":itemsOrder"].map((panelKey, panelIndex) => {
              const panel = tab[":items"][panelKey];
              console.log(panelKey, panel);
              return renderField(panel);
            })}

            {/* Check if 'jsons' exists and has the panelcontainer */}
            {jsons &&
              jsons[":itemsOrder"].map(
                (buttonKey) => {
                  const button =
                    jsons[":items"][buttonKey];
                    console.log(button)
                  return renderField(button);
                }
              )}
          </div>
        )}
      </div>
    );
  })}

    </div>
  );
};
export default FormRenderer;
