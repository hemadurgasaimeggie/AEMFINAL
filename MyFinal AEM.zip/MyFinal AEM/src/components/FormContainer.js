import React from 'react';
import FormRenderer from './FormRenderer'; // Adjust the import path as needed
import jsonData from '../form-model.json'
const FormContainer = () => {
    const title = jsonData?.afModelDefinition?.title;

  return (
    <div>
      <h2>{title}</h2>
      <div style={{ border: '2px solid #000', padding: '20px' }}>
        <FormRenderer />
      </div>
    </div>
  );
};

export default FormContainer;
